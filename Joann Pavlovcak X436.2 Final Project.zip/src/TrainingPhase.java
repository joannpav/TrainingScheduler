/**
 * Created by IntelliJ IDEA.
 * User: joann
 * Date: 6/8/12
 * Time: 6:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class TrainingPhase {
    private String phaseName;
    private String weekPercent;
    private String maxLongRun;
    private String thisWeekLongRun;
    private String pace;
    private String information;
    private String weekNumber;
    private String workInfo1;
    private String thisWeekWorkoutDistance1;
    private String workInfo2;
    private String thisWeekWorkoutDistance2;
    private String workInfo3;
    private String thisWeekWorkoutDistance3;

    public String getWorkInfo1() {
        return workInfo1;
    }

    public void setWorkInfo1(String workInfo1) {
        this.workInfo1 = workInfo1;
    }

    public String getThisWeekWorkoutDistance1() {
        return thisWeekWorkoutDistance1;
    }

    public void setThisWeekWorkoutDistance1(String thisWeekWorkoutDistance1) {
        this.thisWeekWorkoutDistance1 = thisWeekWorkoutDistance1;
    }

    public String getWorkInfo2() {
        return workInfo2;
    }

    public void setWorkInfo2(String workInfo2) {
        this.workInfo2 = workInfo2;
    }

    public String getThisWeekWorkoutDistance2() {
        return thisWeekWorkoutDistance2;
    }

    public void setThisWeekWorkoutDistance2(String thisWeekWorkoutDistance2) {
        this.thisWeekWorkoutDistance2 = thisWeekWorkoutDistance2;
    }

    public String getWorkInfo3() {
        return workInfo3;
    }

    public void setWorkInfo3(String workInfo3) {
        this.workInfo3 = workInfo3;
    }

    public String getThisWeekWorkoutDistance3() {
        return thisWeekWorkoutDistance3;
    }

    public void setThisWeekWorkoutDistance3(String thisWeekWorkoutDistance3) {
        this.thisWeekWorkoutDistance3 = thisWeekWorkoutDistance3;
    }

    public String getPhaseName() {
        return phaseName;
    }

    public void setPhaseName(String phaseName) {
        this.phaseName = phaseName;
    }

    public String getThisWeekLongRun() {
        return thisWeekLongRun;
    }

    public void setThisWeekLongRun(String thisWeekLongRun) {
        this.thisWeekLongRun = thisWeekLongRun;
    }

    public String getWeekNumber() {
        return weekNumber;
    }

    public void setWeekNumber(String weekNumber) {
        this.weekNumber = weekNumber;
    }

    public String getWeekPercent() {
        return weekPercent;
    }

    public void setWeekPercent(String weekPercent) {
        this.weekPercent = weekPercent;
    }

    public String getMaxLongRun() {
        return maxLongRun;
    }

    public void setMaxLongRun(String maxLongRun) {
        this.maxLongRun = maxLongRun;
    }

    public String getPace() {
        return pace;
    }

    public void setPace(String pace) {
        this.pace = pace;
    }

    public String getInformation() {
        return information;
    }

    public void setInformation(String information) {
        this.information = information;
    }


}
